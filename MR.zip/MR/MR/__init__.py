# MR/__init__.py

from .core import run_with_timeout
